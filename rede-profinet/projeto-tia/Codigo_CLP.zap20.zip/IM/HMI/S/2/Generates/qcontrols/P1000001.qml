﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777217
	objId: 16777217
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiQmlRectangle
	{
		id: q671088649
		objId: 671088649
		x: 242
		y: 67
		width: 332
		height: 240
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 332
		qm_RectangleHeight: 240
	}
	IGuiButton
	{
		id: q486539291
		objId: 486539291
		x: 426
		y: 147
		width: 76
		height: 38
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/22#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiButton
	{
		id: q486539292
		objId: 486539292
		x: 373
		y: 97
		width: 76
		height: 38
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/22#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
	IGuiTextField
	{
		id: q268435465
		objId: 268435465
		x: 317
		y: 76
		width: 175
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicView
	{
		id: q301989890
		objId: 301989890
		x: 633
		y: 152
		width: 147
		height: 243
		qm_Transparent : true 
		qm_ImageWidth: 147
		qm_ImageHeight: 243
		qm_SourceSizeWidth: 147
		qm_SourceSizeHeight: 243
	}
	IGuiGraphicView
	{
		id: q301989891
		objId: 301989891
		x: 14
		y: 213
		width: 193
		height: 193
		qm_Transparent : true 
		qm_ImageWidth: 193
		qm_ImageHeight: 193
		qm_SourceSizeWidth: 193
		qm_SourceSizeHeight: 193
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544321
		objId: 335544321
		x: 199
		y: 349
		width: 76
		height: 54
		qm_Transparent : true 
		qm_ImageWidth: 76
		qm_ImageHeight: 54
		qm_SourceSizeWidth: 76
		qm_SourceSizeHeight: 54
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544322
		objId: 335544322
		x: 272
		y: 343
		width: 333
		height: 33
		qm_Transparent : true 
		qm_ImageWidth: 333
		qm_ImageHeight: 33
		qm_SourceSizeWidth: 333
		qm_SourceSizeHeight: 33
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544323
		objId: 335544323
		x: 602
		y: 342
		width: 35
		height: 35
		qm_Transparent : true 
		qm_ImageWidth: 35
		qm_ImageHeight: 35
		qm_SourceSizeWidth: 35
		qm_SourceSizeHeight: 35
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544324
		objId: 335544324
		x: 603
		y: 195
		width: 33
		height: 151
		qm_Transparent : true 
		qm_ImageWidth: 33
		qm_ImageHeight: 151
		qm_SourceSizeWidth: 33
		qm_SourceSizeHeight: 151
	}
	IGuiGraphicIOField
	{
		id: q335544325
		objId: 335544325
		x: 602
		y: 163
		width: 35
		height: 35
		qm_Transparent : true 
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
		qm_ImageWidth: 35
		qm_ImageHeight: 35
		qm_SourceSizeWidth: 35
		qm_SourceSizeHeight: 35
		qm_hasScrollIndicator: false
	}
	IGuiIOField
	{
		id: q33554437
		objId: 33554437
		x: 462
		y: 256
		width: 81
		height: 48
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 4
		qm_RectangleBorder.width:4
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffc6c3c6"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 6
		qm_Anchors.leftMargin: 7
		qm_Anchors.rightMargin: 6
		qm_Anchors.topMargin: 6
	}
	IGuiTextField
	{
		id: q268435466
		objId: 268435466
		x: 273
		y: 201
		width: 176
		height: 42
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088650
		objId: 671088650
		x: 244
		y: 5
		width: 330
		height: 48
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 330
		qm_RectangleHeight: 48
	}
	IGuiTextField
	{
		id: q268435467
		objId: 268435467
		x: 300
		y: 16
		width: 214
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554438
		objId: 33554438
		x: 462
		y: 192
		width: 81
		height: 48
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 4
		qm_RectangleBorder.width:4
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffc6c3c6"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 6
		qm_Anchors.leftMargin: 7
		qm_Anchors.rightMargin: 6
		qm_Anchors.topMargin: 6
	}
	IGuiTextField
	{
		id: q268435468
		objId: 268435468
		x: 304
		y: 266
		width: 112
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiButton
	{
		id: q486539299
		objId: 486539299
		x: 318
		y: 147
		width: 76
		height: 38
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/22#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
}

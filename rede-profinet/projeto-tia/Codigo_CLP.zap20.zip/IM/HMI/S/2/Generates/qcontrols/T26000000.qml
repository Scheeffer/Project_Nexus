﻿import QtQuick 2.7
import "qrc:/"
IGuiTemplate
{	id: q637534208
	objId: 637534208
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiGraphicView
	{
		id: q301989888
		objId: 301989888
		x: 0
		y: 0
		width: 91
		height: 51
		qm_Transparent : true 
		qm_ImageWidth: 91
		qm_ImageHeight: 51
		qm_SourceSizeWidth: 91
		qm_SourceSizeHeight: 51
	}
	IGuiGraphicView
	{
		id: q301989889
		objId: 301989889
		x: 672
		y: 1
		width: 128
		height: 111
		qm_Transparent : true 
		qm_ImageWidth: 128
		qm_ImageHeight: 111
		qm_SourceSizeWidth: 128
		qm_SourceSizeHeight: 111
	}
	IGuiButton
	{
		id: q486539290
		objId: 486539290
		x: 4
		y: 445
		width: 96
		height: 32
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/22#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ff636573"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
}

﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777219
	objId: 16777219
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiQmlRectangle
	{
		id: q671088652
		objId: 671088652
		x: 177
		y: 8
		width: 404
		height: 48
		qm_BorderWidth: 1
		qm_TextColor: "#ff181c31"
		qm_FillColor: "#ffdedbde"
		qm_RectangleWidth: 404
		qm_RectangleHeight: 48
	}
	IGuiTextField
	{
		id: q268435470
		objId: 268435470
		x: 274
		y: 18
		width: 194
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
}
